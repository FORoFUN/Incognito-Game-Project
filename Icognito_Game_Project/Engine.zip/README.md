﻿# nmg355_mja511_ma4096_xw1154_kps325-project
project created for nmg355_mja511_ma4096_xw1154_kps325

# Overview
We’re going to be building a 2d action/adventure steampunk side-scroller in either pygame or unity. Basic idea is that you spawn as a poor person in a London ally and have to progress your way through the (small) city to make it to the richer side to steal some valuables to feed your family. As you progress, you learn the stealth abilities which give you the ability to fade into the background (or other stuff) for a given amount of time.

# Youtube Video Demo
[I'm the Youtube Video Link](https://youtu.be/uyHxyec8C2o)