#Required
##Programming

###Bug Fixes
* Make enemies look the correct direction when player is detected


##Logistics
* Play tests
* Video
* Writeup

#Reach Goals
* Tiling background image
* Coordinate grid system
* Remake world to be neater
